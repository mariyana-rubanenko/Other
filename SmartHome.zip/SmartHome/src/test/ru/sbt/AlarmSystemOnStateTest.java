package ru.sbt;

import org.junit.Test;
import ru.sbt.AlarmSystem;
import ru.sbt.AlarmSystemStateEnum;
import ru.sbt.SensorEvent;
import ru.sbt.SensorEventType;

import static org.junit.Assert.*;

/**
 *Created by maya on 21.12.2017.
 */
public class AlarmSystemOnStateTest {

    private AlarmSystem generateStateOn() {
        AlarmSystem alarmSystem = new AlarmSystem();
        alarmSystem.turnOn();
        return alarmSystem;
    }

    @Test
    public void turnOn() {
        AlarmSystem alarmSystem = generateStateOn();
        alarmSystem.turnOn();
        assertEquals(AlarmSystemStateEnum.ON, alarmSystem.getState());
    }

    @Test
    public void onSensor() {
        AlarmSystem alarmSystem = generateStateOn();
        alarmSystem.onSensor(createSensorEvent());
        assertEquals(AlarmSystemStateEnum.WAIT_FOR_PASSWORD, alarmSystem.getState());
    }

    @Test
    public void turnOff() {
        AlarmSystem alarmSystem = generateStateOn();
        assertEquals(AlarmSystemStateEnum.ON, alarmSystem.getState());
        alarmSystem.turnOff();
        assertEquals(AlarmSystemStateEnum.OFF, alarmSystem.getState());
    }

    @Test
    public void otherMethods() {
        AlarmSystem alarmSystem = generateStateOn();
        alarmSystem.typeCorrectPassword();
        assertEquals(AlarmSystemStateEnum.ON, alarmSystem.getState());
        alarmSystem.typeUncorrectPassword();
        assertEquals(AlarmSystemStateEnum.ON, alarmSystem.getState());
    }

    private SensorEvent createSensorEvent() {
        return new SensorEvent(SensorEventType.DOOR_OPEN, "1");
    }
}