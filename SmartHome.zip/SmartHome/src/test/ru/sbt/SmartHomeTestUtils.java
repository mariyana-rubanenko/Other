package ru.sbt;

import ru.sbt.Door;
import ru.sbt.Light;
import ru.sbt.Room;
import ru.sbt.SmartHome;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;

/**
 * Created by maya on 21.12.2017.
 */
public class SmartHomeTestUtils {
    public static SmartHome creatSmartHome(){
        return creatSmartHome(true,true);
    }

    public static SmartHome creatSmartHome(boolean allLightsIsOn, boolean allDoorsIsOpen){

        SmartHome smartHome = new SmartHome();
        ArrayList<Light> lights = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            lights.add(new Light("Light #" + String.valueOf(i + 1), allLightsIsOn));
        }

        ArrayList<Door> doors = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            doors.add(new Door(allDoorsIsOpen, "Door #" + String.valueOf(i + 1)));
        }

        ArrayList<Room> rooms = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            rooms.add(new Room(lights, doors, "Room #" + String.valueOf(i + 1)));
        }

        for (Room room : rooms) {
            smartHome.addRoom(room);
        }
        return smartHome;
    }
}
