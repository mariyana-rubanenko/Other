package ru.sbt;

public enum CommandType {
    LIGHT_OFF
}
