package ru.sbt;

/**
 * Created by maya on 21.12.2017.
 */
public interface Actionable {
    void executeAction(Action object);
}
