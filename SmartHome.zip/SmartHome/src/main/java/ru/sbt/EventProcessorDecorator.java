package ru.sbt;

/**
 * Created by maya on 21.12.2017.
 */
public class EventProcessorDecorator implements EventProcessor {
    EventProcessor eventProcessor;

    public EventProcessorDecorator(EventProcessor eventProcessor) {
        this.eventProcessor = eventProcessor;
    }

    @Override
    public void processEvent(SmartHome smartHome, SensorEvent event) {
        System.out.println(System.currentTimeMillis());
        eventProcessor.processEvent(smartHome, event);
        System.out.println(System.currentTimeMillis() + " after ");
    }
}
