package ru.sbt;

/**
 * Created by maya on 21.12.2017.
 */
public interface AlarmSystemState {
    void turnOn();
    void onSensor(SensorEvent sensorEvent);
    void turnOff();
    void typeCorrectPassword();
    void typeIncorrectPassword();
    AlarmSystemStateEnum getState();
}

