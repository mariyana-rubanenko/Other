package ru.sbt;

/**
 * Created by maya on 21.12.2017.
 */
public enum AlarmSystemStateEnum {
    ON, WAIT_FOR_PASSWORD, OFF, ALERT
}
